/*
 * @(#)GUIInitializedMulticaster.java	1.3 98/09/01
 * 
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not disclose
 * such Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 * OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY
 * LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR
 * ITS DERIVATIVES.
 * 
 */
package com.sun.java.accessibility.util;

import java.awt.*;
import java.util.EventListener;
import javax.accessibility.*;


/**
 * The GUIInitializedMulticaster class is used to maintain a list of
 * GUIInitializedListener classes.  It is intended to be used primarily
 * for internal support in the EventQueueMonitor class, and is not intended 
 * to be used by classes outside the Java Accessibility Utility package.
 * 
 * @see EventQueueMonitor
 * @see EventQueueMonitor#addGUIInitializedListener
 * @see EventQueueMonitor#removeGUIInitializedListener
 *
 * @version 1.3 09/01/98 15:35:16
 * @author Willie Walker
 */
public class GUIInitializedMulticaster 
    extends AWTEventMulticaster implements GUIInitializedListener
{
    protected GUIInitializedMulticaster(EventListener a, EventListener b) {
	super(a, b);
    }

    public void guiInitialized() {
	((GUIInitializedListener)a).guiInitialized();
	((GUIInitializedListener)b).guiInitialized();
    }

    public static GUIInitializedListener add(GUIInitializedListener a, GUIInitializedListener b) {
	return (GUIInitializedListener)addInternal(a, b);
    }

    public static GUIInitializedListener remove(GUIInitializedListener l, GUIInitializedListener oldl) {
	return (GUIInitializedListener)removeInternal(l, oldl);
    }

    protected static EventListener addInternal(EventListener a, EventListener b) {
	if (a == null)  return b;
	if (b == null)  return a;
	return new GUIInitializedMulticaster(a, b);
    }

    protected static EventListener removeInternal(EventListener l, EventListener oldl) {
	if (l == oldl || l == null) {
	    return null;
	} else if (l instanceof GUIInitializedMulticaster) {
	    return ((GUIInitializedMulticaster)l).remove(oldl);
	} else {
	    return l;		// it's not here
	}
    }

}
